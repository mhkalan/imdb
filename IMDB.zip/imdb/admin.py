from django.contrib import admin
from imdb.models import *
# Register your models here.


admin.site.register(Content)
admin.site.register(Review)
